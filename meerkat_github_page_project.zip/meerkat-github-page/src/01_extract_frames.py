import cv2
from pathlib import Path

VIDEO_PATH = "videos/IMG_1561_2.mp4"
OUTPUT_DIR = Path("frames_IMG1561_for_markup")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
STEP_SEC = 5

cap = cv2.VideoCapture(VIDEO_PATH)
if not cap.isOpened():
    raise RuntimeError("Видео не открылось")

fps = cap.get(cv2.CAP_PROP_FPS)
frame_step = int(fps * STEP_SEC)
frame_id = 0
saved_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break
    if frame_id % frame_step == 0:
        time_sec = frame_id / fps
        cv2.imwrite(str(OUTPUT_DIR / f"IMG1561_t{int(time_sec):04d}.jpg"), frame)
        saved_id += 1
    frame_id += 1

cap.release()
print(f"Сохранено кадров: {saved_id}")
