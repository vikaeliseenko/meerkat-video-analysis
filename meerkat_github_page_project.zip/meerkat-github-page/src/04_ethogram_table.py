import pandas as pd

INPUT_CSV = "results/raw_detections.csv"
OUTPUT_CSV = "results/ethogram_table.csv"
BIN_SIZE_SEC = 30
ENRICHMENT_ZONE = (500, 300, 750, 550)

def point_in_zone(x, y, zone):
    x1, y1, x2, y2 = zone
    return x1 <= x <= x2 and y1 <= y <= y2

def classify_behavior(row):
    x_center = (row["x1"] + row["x2"]) / 2
    y_center = (row["y1"] + row["y2"]) / 2
    if point_in_zone(x_center, y_center, ENRICHMENT_ZONE):
        return "olfactory_interest"
    box_height = row["y2"] - row["y1"]
    box_width = row["x2"] - row["x1"]
    if box_height > box_width * 1.8:
        return "vigilance"
    return "exploratory"

df = pd.read_csv(INPUT_CSV)
df["behavior"] = df.apply(classify_behavior, axis=1)
df["time_bin_start"] = (df["time_sec"] // BIN_SIZE_SEC) * BIN_SIZE_SEC
df["time_bin_end"] = df["time_bin_start"] + BIN_SIZE_SEC

ethogram = (
    df.groupby(["time_bin_start", "time_bin_end", "behavior"])
    .agg(count_events=("behavior", "count"), mean_confidence=("confidence", "mean"))
    .reset_index()
)
ethogram["duration_sec"] = ethogram["count_events"]
ethogram["percent_time"] = (ethogram["duration_sec"] / BIN_SIZE_SEC * 100).round(2)
ethogram.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
print("Этологическая таблица сохранена:", OUTPUT_CSV)
