from ultralytics import YOLO

model = YOLO("yolov8n.pt")
model.train(
    data="dataset/data.yaml",
    epochs=100,
    imgsz=640,
    batch=8,
    name="meerkat_detector"
)
print("Модель сохранена: runs/detect/meerkat_detector/weights/best.pt")
