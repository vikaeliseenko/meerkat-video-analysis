import cv2
import pandas as pd
from ultralytics import YOLO
from pathlib import Path

VIDEO_PATH = "videos/IMG_1561_2.mp4"
MODEL_PATH = "runs/detect/meerkat_detector/weights/best.pt"
OUTPUT_CSV = "results/raw_detections.csv"
OUTPUT_VIDEO = "results/annotated_video.mp4"

Path("results").mkdir(exist_ok=True)
model = YOLO(MODEL_PATH)

cap = cv2.VideoCapture(VIDEO_PATH)
if not cap.isOpened():
    raise RuntimeError("Видео не открылось")

fps = cap.get(cv2.CAP_PROP_FPS)
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
writer = cv2.VideoWriter(OUTPUT_VIDEO, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))

rows = []
frame_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    time_sec = frame_id / fps
    results = model(frame, verbose=False)
    boxes = results[0].boxes

    if boxes is not None:
        for box in boxes:
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
            conf = float(box.conf[0].cpu().numpy())
            rows.append({
                "frame_id": frame_id,
                "time_sec": round(time_sec, 2),
                "class_name": "meerkat",
                "confidence": round(conf, 3),
                "x1": round(float(x1), 1),
                "y1": round(float(y1), 1),
                "x2": round(float(x2), 1),
                "y2": round(float(y2), 1)
            })
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 0, 255), 2)
            cv2.putText(frame, f"meerkat {conf:.2f}", (int(x1), max(20, int(y1)-5)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

    writer.write(frame)
    frame_id += 1

cap.release()
writer.release()
pd.DataFrame(rows).to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
print("Таблица:", OUTPUT_CSV)
print("Видео с рамками:", OUTPUT_VIDEO)
