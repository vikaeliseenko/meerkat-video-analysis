# Meerkat Olfactory Enrichment Video Analysis

Прототип системы автоматизированного анализа поведения сурикат (*Suricata suricatta*) при ольфакторном обогащении среды.

## Конкретные результаты

| Показатель | Результат |
|---|---:|
| Кадров подготовлено для анализа | 107 |
| Размеченных объектов | 214 |
| Классов модели | 1 |
| Класс | `meerkat` |
| Формат разметки | YOLO |
| Precision по графику | 1.00 |
| Confidence при precision = 1.00 | 0.701 |

## Запуск

```bash
pip install -r requirements.txt
python src/01_extract_frames.py
python src/02_train_yolo.py
python src/03_analyze_video.py
python src/04_ethogram_table.py
```

## GitHub Pages

Страница проекта находится в `docs/index.html`.
